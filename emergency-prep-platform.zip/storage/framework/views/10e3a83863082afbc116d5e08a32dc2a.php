<?php $__env->startSection('content'); ?>
    <div id="app">
        <parent-monitoring-component></parent-monitoring-component>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\emergency-prep-platform\resources\views\parent\dashboard.blade.php ENDPATH**/ ?>