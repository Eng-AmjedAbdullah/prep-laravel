<!DOCTYPE html>
<html>
<head>
    <title>Child Registration Notification</title>
</head>
<body>
    <p>Dear Parent,</p>
    <p>Your child {{ $user->username }} has registered on our platform with your email address for parental supervision.</p>
    <p>If you have any concerns, please contact us immediately.</p>
    <p>Thank you for your attention!</p>
</body>
</html>
