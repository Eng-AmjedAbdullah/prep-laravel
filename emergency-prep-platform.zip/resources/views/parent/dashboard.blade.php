@extends('layouts.app')

@section('content')
    <div id="app">
        <parent-monitoring-component></parent-monitoring-component>
    </div>
@endsection
